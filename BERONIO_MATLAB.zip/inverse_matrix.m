function invA = inverse_matrix(A)

if size(A,1) ~= size(A,2)
    error('Matrix must be square');
end

if det(A) == 0
    error('Matrix is singular (no inverse)');
end

invA = inv(A);

end
