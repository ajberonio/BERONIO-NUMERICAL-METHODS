function T = transpose_matrix(A)
    T = A';
end