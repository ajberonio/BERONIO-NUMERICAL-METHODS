function [root, table] = incremental(f, xl, xu)

step = 0.5;
i = 1;

table = strings(0,8);

while true

    x_next = xl + step;

    fxl = f(xl);
    fxu = f(x_next);

    dx = step;
    prod = fxl * fxu;

    % -------------------------
    % REMARK
    % -------------------------
    if prod < 0
        remark = "<0 Revert back to xl & consider smaller interval";
    else
        remark = ">0 Go to next interval";
    end

    % -------------------------
    % STORE (BEFORE CHANGES)
    % -------------------------
    table(end+1,:) = string([
        i, xl, dx, x_next, fxl, fxu, prod, remark
        ]);

    % -------------------------
    % CONDITIONS
    % -------------------------
    if fxl == 0
        root = xl;
        return;

    elseif fxu == 0
        root = x_next;
        return;

    elseif prod < 0
        % revert and refine
        xu = x_next;
        step = step / 2;

    else
        % move forward
        xl = x_next;
    end

    % -------------------------
    % STOP CONDITIONS
    % -------------------------
    if step < 1e-4   % tolerance
        root = xl;
        return;
    end

    if i > 100       % safety limit
        root = xl;
        return;
    end

    i = i + 1;

end

end