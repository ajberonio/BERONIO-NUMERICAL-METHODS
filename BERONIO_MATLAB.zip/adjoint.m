function adjA = adjoint(A)

if size(A,1) ~= size(A,2)
    error('Matrix must be square');
end

n = size(A,1);
cof = zeros(n);

for i = 1:n
    for j = 1:n

        % minor matrix
        M = A;
        M(i,:) = [];
        M(:,j) = [];

        % cofactor
        cof(i,j) = ((-1)^(i+j)) * det(M);

    end
end

% adjoint = transpose of cofactor matrix
adjA = cof';

end