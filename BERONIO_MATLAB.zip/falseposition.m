function [root, table] = falseposition(f, xl, xu, tol)

i = 1;
ea = 100;

table = strings(0,9);
xr_old = 0;

while ea > tol

    fxl = f(xl);
    fxu = f(xu);

    % Regula-Falsi formula
    xr = xu - (fxu * (xl - xu)) / (fxl - fxu);

    fxr = f(xr);

    test = fxl * fxr;

    % error
    if i > 1
        ea = abs((xr - xr_old)/xr) * 100;
    end

    % -------------------------
    % CONDITIONS
    % -------------------------
    if fxr == 0
        remark = "Exact Root";
        table(end+1,:) = [i xl xr xu fxl fxr ea test remark];
        root = xr;
        return;

    elseif test < 0
        xu = xr;
        remark = "xu = xr";

    else
        xl = xr;
        remark = "xl = xr";
    end

    table(end+1,:) = [i xl xr xu fxl fxr ea test remark];

    xr_old = xr;
    i = i + 1;

end

root = xr;

end