function d = determinant(A)

if size(A,1) ~= size(A,2)
    error('Matrix must be square');
end

d = det(A);

end