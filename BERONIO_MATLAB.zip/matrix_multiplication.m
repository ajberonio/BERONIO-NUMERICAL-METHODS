function C = matrix_multiplication(A, B)

if size(A,2) ~= size(B,1)
    error('Columns of A must equal rows of B');
end

C = A * B;

end