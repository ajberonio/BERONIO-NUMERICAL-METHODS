function [root, table] = secant(f, x0, x1, tol)

i = 1;
ea = 100;

table = strings(0,7);

while ea > tol

    fx0 = f(x0);
    fx1 = f(x1);

    % Secant formula
    x2 = x1 - (fx1 * (x0 - x1)) / (fx0 - fx1);

    % error
    if i > 1
        ea = abs((x2 - x1)/x2) * 100;
    end

    % save row
    table(end+1,:) = [i x0 x1 fx0 fx1 x2 ea];

    % check exact root
    if fx1 == 0
        root = x1;
        return;
    end

    % update
    x0 = x1;
    x1 = x2;

    i = i + 1;

end

root = x2;

end