function [root, table] = bisection(f, xl, xu, tol)

i = 1;
ea = 100;
xr_old = 0;

table = strings(0,9);

% -------------------------
% INITIAL SIGN CHECK
% -------------------------
if f(xl) * f(xu) > 0
    error('No sign change. Choose different xl and xu.');
end

while ea > tol

    xr = (xl + xu) / 2;

    fxl = f(xl);
    fxr = f(xr);

    test = fxl * fxr;

    % -------------------------
    % COMPUTE ERROR
    % -------------------------
    if i > 1
        if xr ~= 0
            ea = abs((xr - xr_old)/xr) * 100;
        else
            ea = 0;
        end
    end

    % -------------------------
    % CONDITIONS + REMARKS
    % -------------------------
    if fxr == 0
        remark = "Exact Root";

        % store before exit
        table(end+1,:) = string([i, xl, xr, xu, fxl, fxr, ea, test, remark]);
        root = xr;
        return;

    elseif test < 0
        remark = "<0 1st subinterval (xu = xr)";

    else
        remark = ">0 2nd subinterval (xl = xr)";
    end

    % -------------------------
    % STORE
    % -------------------------
    table(end+1,:) = string([
        i, xl, xr, xu, fxl, fxr, ea, test, remark
        ]);

    % -------------------------
    % UPDATE BOUNDS
    % -------------------------
    if test < 0
        xu = xr;
    else
        xl = xr;
    end

    xr_old = xr;
    i = i + 1;

    % safety stop (optional)
    if i > 100
        break;
    end

end

root = xr;

end