function matrix_menu()

disp(" ");
disp("MATRIX OPERATIONS");
disp("=================");

disp("1. Addition");
disp("2. Multiplication");
disp("3. Determinant");
disp("4. Inverse");
disp("5. Transpose");
disp("6. Adjoint");
disp("7. Power");
disp("8. Solve Ax=b");

choice = input("Choose: ");

switch choice

    case 1
        A = input('Enter matrix A: ');
        B = input('Enter matrix B: ');
        disp(matrix_addition(A,B));

    case 2
        A = input('Enter matrix A: ');
        B = input('Enter matrix B: ');
        disp(matrix_multiplication(A,B));

    case 3
        A = input('Enter matrix: ');
        disp(determinant(A));

    case 4
        A = input('Enter matrix: ');
        disp(inverse_matrix(A));

    case 5
        A = input('Enter matrix: ');
        disp(transpose_matrix(A));

    case 6
        A = input('Enter matrix: ');
        disp(adjoint(A));

    case 7
        A = input('Enter matrix: ');
        n = input('Enter power: ');
        disp(matrix_power(A,n));

    case 8
        A = input('Enter matrix A: ');
        b = input('Enter vector b: ');
        disp(equations(A,b));

    otherwise
        disp("Invalid choice");

end

end