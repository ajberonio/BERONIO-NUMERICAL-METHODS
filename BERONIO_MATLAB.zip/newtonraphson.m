function [root, table] = newtonraphson(f, x0, tol)

i = 1;
ea = 100;

table = strings(0,6);

while ea > tol

    fx = f(x0);

    % numerical derivative
    h = 1e-6;
    dfx = (f(x0 + h) - f(x0)) / h;

    % formula
    x1 = x0 - fx/dfx;

    % error
    if i > 1
        ea = abs((x1 - x0)/x1) * 100;
    end

    % save row
    table(end+1,:) = [i x0 fx dfx x1 ea];

    % check exact root
    if fx == 0
        root = x0;
        return;
    end

    % update
    x0 = x1;
    i = i + 1;

end

root = x1;

end