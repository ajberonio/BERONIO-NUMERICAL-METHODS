function main()
clc;
clear;

disp("NUMERICAL METHODS & MATRIX CALCULATOR");
disp("====================================");

while true

    disp(" ");
    disp("1. Incremental Method");
    disp("2. Bisection Method");
    disp("3. False Position");
    disp("4. Newton-Raphson");
    disp("5. Secant Method");
    disp("6. Matrix Operations");
    disp("0. Exit");

    choice = input("Choose option: ");

    switch choice

        case 1
            f = input('Enter function @(x): ');
            xl = input('Enter xl: ');
            xu = input('Enter xu: ');
            [root, table] = incremental(f, xl, xu);
            disp(root);
            disp(table);

        case 2
            f = input('Enter function @(x): ');
            xl = input('Enter xl: ');
            xu = input('Enter xu: ');
            tol = input('Enter tolerance: ');
            [root, table] = bisection(f, xl, xu, tol);
            disp(root);
            disp(table);

        case 3
            f = input('Enter function @(x): ');
            xl = input('Enter xl: ');
            xu = input('Enter xu: ');
            tol = input('Enter tolerance: ');
            [root, table] = falseposition(f, xl, xu, tol);
            disp(root);
            disp(table);

        case 4
            f = input('Enter function @(x): ');
            x0 = input('Enter initial guess: ');
            tol = input('Enter tolerance: ');
            [root, table] = newtonraphson(f, x0, tol);
            disp(root);
            disp(table);

        case 5
            f = input('Enter function @(x): ');
            x0 = input('Enter x0: ');
            x1 = input('Enter x1: ');
            tol = input('Enter tolerance: ');
            [root, table] = secant(f, x0, x1, tol);
            disp(root);
            disp(table);

        case 6
            matrix_menu();

        case 0
            disp("Exiting...");
            break;

        otherwise
            disp("Invalid choice");

    end
end

end