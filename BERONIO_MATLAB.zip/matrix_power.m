function P = matrix_power(A, n)

if size(A,1) ~= size(A,2)
    error('Matrix must be square');
end

if n < 0
    error('Power must be non-negative');
end

P = A^n;

end