function x = equations(A, b)

if size(A,1) ~= size(A,2)
    error('Matrix A must be square');
end

if size(A,1) ~= size(b,1)
    error('A and b must have compatible sizes');
end

x = A \ b;   % Gaussian elimination (built-in)

end